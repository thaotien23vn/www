$(document).ready(function() {
    $("#productForm").submit(function(event) {
        let isValid = true;
        let firstInvalidElement = null; // Biến lưu trữ element không hợp lệ đầu tiên


        // Validate Code
        const code = $("#code").val();
        if (code.trim() === "") {
            $("#codeError").text("Code cannot be empty.");
            setInvalid(code, "#codeError");
            isValid = false;

        } else if (code.length > 10 || !/^[A-Za-z0-9]+$/.test(code)) {
            $("#codeError").text("Code must be at most 10 characters and contain only letters and numbers.");
            setInvalid(code, "#codeError");
            isValid = false;
        } else {
            $("#codeError").text("");
            setValid(code, "#codeError");

        }

        // Validate Name
        const name = $("#name").val();
        if (name.trim() === "") {
            $("#nameError").text("Name cannot be empty.");
             setInvalid(name, "#nameError");
            isValid = false;
        } else if (name.length > 50 || !/^[A-Za-z0-9\s]+$/.test(name)) {
            $("#nameError").text("Name must be at most 50 characters and contain only letters, numbers, and spaces.");
            setInvalid(name, "#nameError");

            isValid = false;
        } else {
            $("#nameError").text("");
            setValid(name, "#nameError");

        }

        // Validate Price
        const price = $("#price").val();
        if (price.trim() === "") {
            $("#priceError").text("Price cannot be empty.");
            setInvalid(price, "#priceError");

            isValid = false;
        } else if (price <= 0 || !/^\d+(\.\d{1,2})?$/.test(price)) {
            $("#priceError").text("Price must be greater than 0 and have at most 2 decimal places.");
           setInvalid(price, "#priceError");

            isValid = false;
        } else {
            $("#priceError").text("");
           setValid(price, "#priceError");

        }

        // Validate Description
        const description = $("#description").val();
        if (description.trim() === "") {
            $("#descriptionError").text("Description cannot be empty.");
            setInvalid(description, "#descriptionError");

            isValid = false;
        } else if (description.length > 1000) {
            $("#descriptionError").text("Description must be at most 1000 characters.");
            setInvalid(description, "#descriptionError");
            isValid = false;

        } else {
            $("#descriptionError").text("");
           setValid(description, "#descriptionError");

        }

        // registered date
        const registeredDate = $("#registeredDate").val();
        if (registeredDate.trim() === "") {
            $("#registeredDateError").text("Registered date cannot be empty.");
             setInvalid(registeredDate, "#registeredDateError");

            isValid = false;
        } else {
           $("#registeredDateError").text("");
            setValid(registeredDate, "#registeredDateError");

        }

         // category
        const category = $("#category").val();
        if (category == null || category === "") {
            $("#categoryError").text("Category cannot be empty.");
             setInvalid(category, "#categoryError");
            isValid = false;

        } else {
           $("#categoryError").text("");
            setValid(category, "#categoryError");

        }

        // is active
        if (!$("input[name='isActive']").is(":checked")) {
            $("#activeStatusError").text("Please select an active status.");
            isValid = false;
        } else {
             $("#activeStatusError").text("");
        }

        if (!isValid) {
            event.preventDefault();
            // Focus vào element không hợp lệ đầu tiên
           if (firstInvalidElement) {
                firstInvalidElement.focus();
            }
        }



    });


    //set invalid
     function setInvalid(element, errorElement) {
            $(element).addClass("is-invalid");
             $(errorElement).addClass("invalid-feedback");
             if (!firstInvalidElement) {
                 firstInvalidElement = $(element);
             }
        }


     // set valid
     function setValid(element, errorElement) {
            $(element).removeClass("is-invalid");
             $(errorElement).removeClass("invalid-feedback");

        }



    $("#btnCancel").click(function() {
        window.location.href = "/products"; // Redirect to product list page
    });
});