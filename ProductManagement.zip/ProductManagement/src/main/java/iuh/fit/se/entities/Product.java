package iuh.fit.se.entities;


import java.math.BigDecimal;
import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;


//lombok
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@ToString


@Entity
@Table (name = "product")
public class Product {
	@Id
	@GeneratedValue (strategy = GenerationType.IDENTITY)
	private int id;
	
	
	@Column (name = "code", length = 10)
	@NotBlank (message = "Code cannot be blank")
	@Size (max = 10, message = "Code must be at most 10 characters")
	@Pattern (regexp = "^[A-Za-z0-9]+$", message = "Code must only contain letters and numbers")
	private String code;
	
	
	@Column (name = "name", length = 50)
	@NotBlank (message = "Product Name cannot be blank")
	@NotEmpty (message = "Product Name cannot be empty")
	@NotNull (message = "Product Name cannot be null")
	@Size (max = 50, message = "Product Name must be at most 50 characters")
	private String name;
	

	// precision là tổng số chữ số, scale là số chữ số thập phân
	// VD: precision = 10, scale = 2 cho phép lưu các số từ -99999999.99 đến 99999999.99.
	@Column (name = "price", precision = 10, scale = 2) // precision và scale cho BigDecimal
    @NotNull (message = "Price cannot be null")
    @Positive (message = "Price must be greater than 0")
	private BigDecimal price;
	
	
	@Column (name = "description", length = 1000)
	@Size (max = 1000, message = "Description must be at most 1000 characters")
	private String description;
	
	@Column (name = "registered_date")
	@DateTimeFormat (pattern = "yyyy-MM-dd") // Thay đổi pattern ở đây
	@Temporal (TemporalType.DATE)
	private Date registeredDate;
	
	
	@Column (name = "is_active")
	private Boolean isActive;
	
	
	@ToString.Exclude
	@JsonIgnore
	@ManyToOne (fetch = FetchType.LAZY)
	@JoinColumn (name = "category_id", referencedColumnName = "id")
	private Category category;

}
