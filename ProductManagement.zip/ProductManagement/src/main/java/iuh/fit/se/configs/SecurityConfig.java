package iuh.fit.se.configs;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;


@Configuration
@EnableWebSecurity
public class SecurityConfig {
    
    @Autowired
    private UserDetailsService userDetailsService;


    /**
     * Bean này cấu hình cách xử lý các request
     * @param http
     * @return
     * @throws Exception
     */
    @Bean
    public SecurityFilterChain filterChain (HttpSecurity http) throws Exception {
    	// This section defines the access rules for different URL patterns
        http.authorizeHttpRequests(requests -> requests
        		// Only users with the "ADMIN" role can access URLs starting with /products
                        .requestMatchers("/products", "/products/new", "/products/{id}", "/products/delete/{id}", "/products*").hasRole("ADMIN")
                // Only users with the "USER" role can access URLs starting with /user       
                        .requestMatchers("/user", "/user*").hasRole("USER")
                // Only logged-in users with either the ADMIN or USER role can access the homepage 
                        .requestMatchers("/").hasAnyRole("ADMIN", "USER")
                // All other requests require authentication. Users must be logged in to access them      
                        .anyRequest().authenticated()
                )
        	// Configures the login process.
//                .formLogin(form -> form
                	// Specifies the custom login page URL.
//                        .loginPage("/login")
                    // Allows everyone to access the login page   
//                        .permitAll()
                    // Redirect to home page after successful login for both roles                           
//                        .defaultSuccessUrl("/", true) 
                    // redirect to /login?error=true if login failed.
//                        .failureUrl("/login?error=true") 
//                )
        			.formLogin(Customizer.withDefaults())
           // Configures the logout process.
//                .logout(logout -> logout
//                		// Specifies the logout URL
//                        .logoutRequestMatcher(new AntPathRequestMatcher("/logout"))
//                        //  Redirects to the login page after logout
//                        .logoutSuccessUrl("/login")
//                        //  Allows everyone to access the logout URL
//                        .permitAll());
        			
        			.logout(Customizer.withDefaults());

        return http.build();
    }


    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

//    @Autowired
//    public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
//        auth.userDetailsService(userDetailsService).passwordEncoder(passwordEncoder);
//    }    
    
    
}
