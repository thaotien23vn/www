package iuh.fit.se.services.impl;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import iuh.fit.se.entities.Product;
import iuh.fit.se.exceptions.ItemNotFoundException;
import iuh.fit.se.repositories.ProductRepository;
import iuh.fit.se.services.ProductService;


@Service
public class ProductServiceImpl implements ProductService {
	@Autowired
	private ProductRepository productRepository;
	
	
	@Override
	public Product findById (int id) {
		return this.productRepository.findById(id)
				.orElseThrow(() -> new ItemNotFoundException("No products found for this ID: " + id));
	}


	@Override
	public List<Product> findAll() {
		return this.productRepository.findAll();
	}


	@Transactional
	@Override
	public Product save(Product product) {
		return this.productRepository.save(product);
	}


	@Transactional
	@Override
	public Product update (Product product) {
		Product productInDB = productRepository.findById(product.getId()) //Check Product available
				.orElseThrow(() -> new ItemNotFoundException("No products found for this ID: " + product.getId()));
		
		if (productInDB == null)
			return null;
		else {
			//productInDB.setXXX(product.getXXX); set giá trị product mới vào product có sẵn trong DB
			productInDB.setCode(product.getCode());
			productInDB.setName(product.getName());
			productInDB.setPrice(product.getPrice());
			productInDB.setDescription(product.getDescription());
			productInDB.setRegisteredDate(product.getRegisteredDate());
			productInDB.setIsActive(product.getIsActive());
			productInDB.setCategory(product.getCategory());

			Product updatedProduct = productRepository.save(productInDB);
			return updatedProduct; // trả về updated product, giúp frontend kiểm tra lại thông tin mới nhất	
		}
	}


	@Override
	public boolean delete (int id) {
		Product product = this.findById(id);
		productRepository.delete(product);
		return true;
	}
}
