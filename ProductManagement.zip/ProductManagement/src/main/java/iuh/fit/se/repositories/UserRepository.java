package iuh.fit.se.repositories;


import org.springframework.data.jpa.repository.JpaRepository;
import iuh.fit.se.entities.User;


public interface UserRepository extends JpaRepository<User, Integer> {
	User findByEmail(String email);
	User findByUsername(String username);
}
