package iuh.fit.se.services;


import java.util.List;

import org.springframework.data.domain.Page;

import iuh.fit.se.entities.Category;


public interface CategoryService {
	public List<Category> findAll();
	public Category findById (int id);
	public Category save (Category category);
	public Category update (int id, Category category);
	public boolean delete (int id);
}
