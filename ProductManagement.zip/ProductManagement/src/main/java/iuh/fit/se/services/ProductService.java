package iuh.fit.se.services;


import java.util.List;

import org.springframework.data.domain.Page;
import iuh.fit.se.entities.Product;


public interface ProductService {
	public List<Product> findAll();
	public Product findById (int id);
	public Product save (Product product);
	public Product update (Product product);
	public boolean delete (int id);
	
}
