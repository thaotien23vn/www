package iuh.fit.se.services.impl;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import iuh.fit.se.entities.Category;
import iuh.fit.se.exceptions.ItemNotFoundException;
import iuh.fit.se.repositories.CategoryRepository;
import iuh.fit.se.services.CategoryService;


@Service
public class CategoryServiceImpl implements CategoryService {
	@Autowired
	private CategoryRepository categoryRepository;
	
	
	@Override
	public List<Category> findAll() {
		return this.categoryRepository.findAll();
	}


	@Override
	public Category findById (int id) {
		return this.categoryRepository.findById(id)
				.orElseThrow(() -> new ItemNotFoundException("No categories found for this ID: " + id));
	}


	@Override
	public Category save(Category category) {
		return this.categoryRepository.save(category);
	}


	@Override
	public Category update(int id, Category category) {
		this.findById(id);
		categoryRepository.save(category);
		return category;
	}


	@Override
	public boolean delete(int id) {
		Category category = this.findById(id);
		categoryRepository.delete(category);
		return true;
	}
}
