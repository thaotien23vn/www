package iuh.fit.se.controllers;


import java.util.List;
import java.util.ArrayList;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.bind.annotation.RequestParam;

import iuh.fit.se.entities.Category;
import iuh.fit.se.entities.Product;
import iuh.fit.se.exceptions.ItemNotFoundException;
import iuh.fit.se.repositories.ProductRepository;
import iuh.fit.se.services.CategoryService;
import iuh.fit.se.services.ProductService;

import jakarta.validation.Valid;


@Controller
public class ProductController {
	@Autowired
	private ProductService productService;
	
	@Autowired
	private ProductRepository productRepository;
	
	@Autowired
	private CategoryService categoryService; 
	

	/**
	 * Hiển thị trang login
	 */
	@GetMapping("/login")
	public String showLoginForm (Model model) {
		model.addAttribute("pageTitle", "Login Page");
		return "login";
	}
	
	
	/**
	 * Hiển thị form error
	 */
	@GetMapping("/error")
	public String showErrorForm (Model model) {
		model.addAttribute("pageTitle", "Error Page");
		return "error";
	}
	
	
	/**
	 * Hiển thị trang danh sách sản phẩm dành cho user
	 */
	/*
	 * @GetMapping("/user") public String showUserPage (Model model) { List<Product>
	 * products = productService.findAll();
	 * 
	 * model.addAttribute("pageTitle", "User Page"); model.addAttribute("products",
	 * products);
	 * 
	 * return "user"; }
	 */
	
	
	/**
	 * Hiển thị form add product
	 */
	@GetMapping("/products/new")
	public String showAddForm (Model model) {
		Product product = new Product();
		
		model.addAttribute("product", product);
		model.addAttribute("pageTitle", "Create a new Product");
		
		List<Category> categories = categoryService.findAll(); 
	    model.addAttribute("categories", categories); 
		
		return "product/form";
	}
	

	/**
	 * Hiển thị form edit product
	 */
	@GetMapping("/products/{id}")
	public String showEditForm (
			@PathVariable("id") Integer id, 
			Model model, 
			RedirectAttributes redirectAttributes
	) {
	    try {
	        Product product = productService.findById(id);
	        model.addAttribute("product", product);
	        model.addAttribute("pageTitle", "Edit Product (ID: " + id + ")");
	        List<Category> categories = categoryService.findAll();
	        model.addAttribute("categories", categories);
	        return "product/form"; 
	    } catch (ItemNotFoundException e) {
	    	redirectAttributes.addFlashAttribute("message", e.getMessage());
	        return "redirect:/products";
	    }
	}
	  

	/**
	 * Phương thức này được gọi khi user submit form
	 * Chức năng lưu thông tin sản phẩm (sau khi thêm mới hoặc cập nhật SP)
	 * @return - Chuyển hướng về trang danh sách sản phẩm sau khi lưu thành công
	 * @PostMapping("/products/new") - Annotation này chỉ định rằng phương thức sẽ xử lý các request POST tới endpoint /products/new
	 * RedirectAttributes - Giúp truyền dữ liệu 1 lần duy nhất đến view, tránh việc message hiển thị lặp lại khi user refresh trang. 
	 */
	@PostMapping("/products/new")
//	@PutMapping("/products/new")
	public String saveProduct (
			@Valid @ModelAttribute("product") Product product, 
			BindingResult bindingResult, 
			Model model, 
			RedirectAttributes ra
	) {		
	
		if (bindingResult.hasErrors()) {
		    model.addAttribute("pageTitle", product.getId() != 0 ? "Edit Product (ID: " + product.getId() + ")" : "Create A New Product");
		    // Get all categories for the select tag.  
		    List<Category> categories = categoryService.findAll();  
			model.addAttribute("categories", categories);

			return "product/form"; 
	    }		
		productService.save(product); //Update or Add product in DB
        ra.addFlashAttribute("message", "The product has been saved successfully.");		
        
        return "redirect:/products"; 		
	}
	
	
	@GetMapping("/products/delete/{id}")
	public String deleteProduct (
			@PathVariable("id") Integer id, 
			RedirectAttributes redirectAttributes
	) {
	    try {
	        productService.delete(id);
	        redirectAttributes.addFlashAttribute("message", "The product ID " + id + " has been deleted.");
	    } catch (ItemNotFoundException e) {
	    	redirectAttributes.addFlashAttribute("message", e.getMessage());
	    }
	    return "redirect:/products";
	}
	
	
	/**
	 * Chức năng tìm kiếm và hiển thị danh sách sản phẩm
	 * @param categoryId
	 * @param isActive
	 * @param registeredDateStr
	 * @param dateRange
	 * @param model
	 * @return
	 * @throws ParseException
	 */
	@GetMapping("/products")
	public String listProducts (
	    @RequestParam(value = "categoryId", required = false) Integer categoryId,
	    @RequestParam(value = "isActive", required = false) Boolean isActive,
	    @RequestParam(value = "registeredDate", required = false) String registeredDateStr,
	    @RequestParam(value = "dateRange", required = false) String dateRange,
	    Model model
	) throws ParseException {

	    Date registeredDate = null;
	    if (registeredDateStr != null && !registeredDateStr.isEmpty()) {
	        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
	        registeredDate = dateFormat.parse(registeredDateStr);
	    }

	    Date startDate = null;
	    Date endDate = null;

	    if (registeredDate != null && dateRange != null) {
	        if ("7days".equals(dateRange)) {
	            startDate = calculateStartDate(registeredDate, 7);
	            endDate = registeredDate;
	        } else if ("1month".equals(dateRange)) {
	            startDate = calculateStartDate(registeredDate, 30);
	            endDate = registeredDate;
	        } else if ("2months".equals(dateRange)) {
	            startDate = calculateStartDate(registeredDate, 60);
	            endDate = registeredDate;
	        } else {
	            startDate = registeredDate; // Nếu không chọn khoảng thời gian, tìm kiếm chính xác ngày đã chọn
	            endDate = registeredDate;
	        }
	    } else if (registeredDate != null) { // trường hợp chỉ có registeredDate mà không có dateRange
	        startDate = registeredDate;
	        endDate = registeredDate;
	    }


	    List<Product> products = productRepository.searchProducts(categoryId, isActive, registeredDate, startDate, endDate);
	    List<Category> categories = categoryService.findAll();

	    model.addAttribute("products", products);
	    model.addAttribute("categories", categories);
	    model.addAttribute("categoryId", categoryId); // Giữ lại categoryId đã chọn trong filter
	    model.addAttribute("isActive", isActive); // Giữ lại isActive đã chọn trong filter
	    model.addAttribute("registeredDate", registeredDate); // Giữ lại registeredDate đã chọn trong filter


	    return "product/list";
	}
	
	
	/**
	 * Chức năng tìm kiếm và hiển thị danh sách sản phẩm
	 * @param categoryId
	 * @param isActive
	 * @param registeredDateStr
	 * @param dateRange
	 * @param model
	 * @return
	 * @throws ParseException
	 */
	@GetMapping("/user")
	public String listProductsForUserPage (
			@RequestParam(value = "categoryId", required = false) Integer categoryId,
			@RequestParam(value = "isActive", required = false) Boolean isActive,
			@RequestParam(value = "registeredDate", required = false) String registeredDateStr,
			@RequestParam(value = "dateRange", required = false) String dateRange,
			Model model
			) throws ParseException {
		
		Date registeredDate = null;
		if (registeredDateStr != null && !registeredDateStr.isEmpty()) {
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			registeredDate = dateFormat.parse(registeredDateStr);
		}
		
		Date startDate = null;
		Date endDate = null;
		
		if (registeredDate != null && dateRange != null) {
			if ("7days".equals(dateRange)) {
				startDate = calculateStartDate(registeredDate, 7);
				endDate = registeredDate;
			} else if ("1month".equals(dateRange)) {
				startDate = calculateStartDate(registeredDate, 30);
				endDate = registeredDate;
			} else if ("2months".equals(dateRange)) {
				startDate = calculateStartDate(registeredDate, 60);
				endDate = registeredDate;
			} else {
				startDate = registeredDate; // Nếu không chọn khoảng thời gian, tìm kiếm chính xác ngày đã chọn
				endDate = registeredDate;
			}
		} else if (registeredDate != null) { // trường hợp chỉ có registeredDate mà không có dateRange
			startDate = registeredDate;
			endDate = registeredDate;
		}
		
		
		List<Product> products = productRepository.searchProducts(categoryId, isActive, registeredDate, startDate, endDate);
		List<Category> categories = categoryService.findAll();
		
		model.addAttribute("products", products);
		model.addAttribute("categories", categories);
		model.addAttribute("categoryId", categoryId); // Giữ lại categoryId đã chọn trong filter
		model.addAttribute("isActive", isActive); // Giữ lại isActive đã chọn trong filter
		model.addAttribute("registeredDate", registeredDate); // Giữ lại registeredDate đã chọn trong filter
		
		
		return "/user";
	}
	

    private Date calculateStartDate(Date endDate, int days) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(endDate);
        calendar.add(Calendar.DAY_OF_MONTH, -days);
        return calendar.getTime();
    }
}
