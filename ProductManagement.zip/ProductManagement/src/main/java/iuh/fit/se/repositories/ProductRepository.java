package iuh.fit.se.repositories;


import java.util.Date;
import java.util.List;

import iuh.fit.se.entities.Product;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;


public interface ProductRepository extends JpaRepository<Product, Integer> {
	List<Product> findByNameContainingIgnoreCase (String keyword);
	
	
	@Query ("SELECT p FROM Product p " +
            "WHERE (:categoryId IS NULL OR p.category.id = :categoryId) " +
            "AND (:isActive IS NULL OR p.isActive = :isActive) " +
            "AND (:registeredDate IS NULL OR p.registeredDate BETWEEN :startDate AND :endDate)"
    )
    List<Product> searchProducts (
        @Param("categoryId") Integer categoryId, 
        @Param("isActive") Boolean isActive, 
        @Param("registeredDate") Date registeredDate,
        @Param("startDate") Date startDate,
        @Param("endDate") Date endDate
    );
}
