package fit.iuh.se.repositories;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import fit.iuh.se.entities.Doctor;


@Repository
public interface DoctorRepository extends JpaRepository<Doctor, Integer> {

    @Query(value = "SELECT * FROM doctor d WHERE d.full_name LIKE %:keyword%"
            + " OR d.email LIKE %:keyword%"
            + " OR d.gender LIKE %:keyword%"
            + " OR CAST(d.experience AS CHAR) LIKE %:keyword%", nativeQuery = true)
    List<Doctor> search(@Param("keyword") String keyword);
}
