package fit.iuh.se.services.impl;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import fit.iuh.se.entities.Doctor;
import fit.iuh.se.repositories.DoctorRepository;
import fit.iuh.se.services.DoctorService;

@Service
public class DoctorServiceImpl implements DoctorService {

    @Autowired
    private DoctorRepository doctorRepository;

    // Lấy tất cả bác sĩ
    @Override
    public List<Doctor> findAll() {
        return doctorRepository.findAll();
    }

    // Lấy danh sách bác sĩ với phân trang
    @Override
    public Page<Doctor> findAllWithPaging(int pageNo, int pageSize, String sortBy, String sortDirection) {
        Sort sort = sortDirection.equalsIgnoreCase("ASC") ? Sort.by(sortBy).ascending() : Sort.by(sortBy).descending();
        Pageable pageable = PageRequest.of(pageNo, pageSize, sort);
        return doctorRepository.findAll(pageable);
    }

    // Tìm bác sĩ theo ID
    @Override
    public Doctor findById(int id) {
        return doctorRepository.findById(id).orElse(null);
    }

    // Lưu hoặc cập nhật bác sĩ
    @Override
    public void save(Doctor doctor) {
        doctorRepository.save(doctor);
    }

    // Xóa bác sĩ theo ID
    @Override
    public void delete(int id) {
        doctorRepository.deleteById(id);
    }

    // Tìm kiếm bác sĩ theo từ khóa
    @Override
    public List<Doctor> search(String keyword) {
        return doctorRepository.search(keyword);
    }
}
