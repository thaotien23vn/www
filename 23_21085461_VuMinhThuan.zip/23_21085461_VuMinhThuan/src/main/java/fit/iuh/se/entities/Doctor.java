package fit.iuh.se.entities;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;

@Entity
@Table(name = "doctor")
public class Doctor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(name = "full_name", length = 50)
    @NotEmpty(message = "Full Name must not be empty")
    private String fullName;

    @Column(name = "email", length = 50, unique = true)
    @NotEmpty(message = "Email must not be empty")
    @Email(message = "Email should be valid")
    private String emailAddress;

    @Column(name = "gender")
    @NotEmpty(message = "Gender must be selected")
    private String gender;

    @Past(message = "Date of birth must be before today")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date dob;

    @PositiveOrZero(message = "Experience years must be zero or positive")
    @Column(name = "experience_years")
    private int experienceYears;

    @Column(name = "note", length = 255)
    private String note;

    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @Temporal(TemporalType.DATE)
    @Column(name = "reg_date")
    private Date regDate;

    public Doctor() {
        super();
    }

    public Doctor(String fullName, String emailAddress, String gender, Date dob, int experienceYears, String note, Date regDate) {
        super();
        this.fullName = fullName;
        this.emailAddress = emailAddress;
        this.gender = gender;
        this.dob = dob;
        this.experienceYears = experienceYears;
        this.note = note;
        this.regDate = regDate;
    }

    // Getters and setters

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getEmailAddress() {
        return emailAddress;
    }

    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public int getExperienceYears() {
        return experienceYears;
    }

    public void setExperienceYears(int experienceYears) {
        this.experienceYears = experienceYears;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public Date getRegDate() {
        return regDate;
    }

    public void setRegDate(Date regDate) {
        this.regDate = regDate;
    }

    @Override
    public String toString() {
        return "Doctor [id=" + id + ", fullName=" + fullName + ", emailAddress=" + emailAddress 
                + ", gender=" + gender + ", dob=" + dob + ", experienceYears=" + experienceYears 
                + ", note=" + note + ", regDate=" + regDate + "]";
    }
}
