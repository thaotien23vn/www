package fit.iuh.se.services;

import java.util.List;
import org.springframework.data.domain.Page;
import fit.iuh.se.entities.Doctor;

public interface DoctorService {
    List<Doctor> findAll();
    Page<Doctor> findAllWithPaging(int pageNo, int pageSize, String sortBy, String sortDirection);
    Doctor findById(int id);
    void save(Doctor doctor);
    void delete(int id);
    List<Doctor> search(String keyword);
}

